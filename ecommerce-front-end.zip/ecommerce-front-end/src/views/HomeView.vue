<script setup>
</script>

<template>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Simple Responsive Website in HTML CSS</title>
  </head>
  <body>
    <main>
      <!-- Header Start -->
      <header>
        <nav class="nav container">
          <h2 class="nav_logo" style="margin-right:10px"><a href="#">PhoneZone</a></h2>

          <ul class="menu_items">
            <li><a href="/" class="nav_link" >Home</a></li>
            <li><a href="/shop" class="nav_link" id="current">Shop</a></li>
            <li><a id="shopCart" class="nav_link"><img src="https://cdn-icons-png.flaticon.com/512/1413/1413908.png"></img></a></li>
            <li><a href="/login" class="nav_link"><img src="https://cdn-icons-png.flaticon.com/512/266/266033.png"></img></a></li>
          </ul>
        </nav>
      </header>
      <!-- Header End -->

      <!-- Hero Start -->
      <section class="hero">
        <div class="row container">
          <div id="cards">
          </div>
        </div>
      </section>
      <!-- Hero End-->
    </main>
  </body>
</template>

<script>
function displayCard(produit) {
  const cardsDiv = document.getElementById('cards');
  const article = document.createElement('article');
  article.classList.add('card');
  article.style.margin = '20px';
  article.style.gridTemplateRows = 'max-content 200px 1fr';
  const img = document.createElement('img');
  img.src = 'https://www.francetvinfo.fr/pictures/g9fLoETH0rcUlgXfCgnHMdYYtz4/1200x900/2024/05/04/the-phone-66360ede76c52156185981.jpg';
  img.style.borderRadius = '10px';
  img.style.width = '200px';
  img.style.height = '200px';
  article.appendChild(img);
  const content = document.createElement('div');
  content.classList.add('content');
  const companyName = document.createElement('h1');
  companyName.textContent = produit.company;
  content.appendChild(companyName);

  const productName = document.createElement('h4');
  productName.textContent = produit.name;
  content.appendChild(productName);

  const price = document.createElement('h3');
  price.textContent = produit.price+'€';
  price.style.marginLeft = '70%';
  content.appendChild(price);

  const quantityDiv = document.createElement('div');
  quantityDiv.classList.add('quantity-picker');
  const decreaseButton = document.createElement('button');
  decreaseButton.textContent = '-';
  decreaseButton.classList.add('btn-quantity');
  decreaseButton.addEventListener('click', () => {
      let quantity = parseInt(quantityInput.value);
      if (quantity > 1) quantityInput.value = quantity - 1;
  });
  quantityDiv.appendChild(decreaseButton);
  const quantityInput = document.createElement('input');
  quantityInput.type = 'number';
  quantityInput.value = 1;
  quantityInput.min = 1;
  quantityInput.classList.add('quantity-input');
  quantityDiv.appendChild(quantityInput);
  const increaseButton = document.createElement('button');
  increaseButton.textContent = '+';
  increaseButton.classList.add('btn-quantity');
  increaseButton.addEventListener('click', () => {
      let quantity = parseInt(quantityInput.value);
      quantityInput.value = quantity + 1;
  });
  quantityDiv.appendChild(increaseButton);
  content.appendChild(quantityDiv);

  const buttonsDiv = document.createElement('div');
  buttonsDiv.classList.add('buttons');
  const button = document.createElement('button');
  button.classList.add('btn');
  button.textContent = 'Add to cart';
  button.addEventListener('click', () => {
      quantity_phone = quantityInput.value;
      addToCart(produit,quantity_phone);
      updateCartDisplay();

  });
  buttonsDiv.appendChild(button);
  content.appendChild(buttonsDiv);
  article.appendChild(content);
  cardsDiv.appendChild(article);
}
fetch('https://ztp2sff6r0.execute-api.eu-west-3.amazonaws.com/products',{
    method: 'GET',
    headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'         // Ensure content type is correct
    }
}).then(response => {
    console.log(response)
    if (!response.ok) {
      throw new Error('Network response was not ok ' + response.statusText);
    }
    return response.json();  // Parse JSON data from the response
  })
  .then(data => {
    var doc = document.getElementById('product-list');
    for (const element of data){
        var produit = element[0]
        //displayCard(produit);
    }
  })
  .catch(error => {
    console.error('There was a problem with the fetch operation:', error);
});
const divCart = document.createElement('div');
divCart.style.width = '200px';
divCart.style.height = '200px';
divCart.style.backgroundColor = 'red';


// Initialize an empty cart ---------------------------------
let cart = [];

function addToCart(produit, quantity) {
  item = [produit,quantity];
  cart.push({ item });
}
/*
function updateCartDisplay() {
  totalPrice = 0;
  cart.forEach(item => {
    p = item[0];
    q = item[1];
    
    listItem.textContent = `${item.name} - ${item.price}€`;
    cartItemsContainer.appendChild(listItem);
    totalPrice += item.price;
  });
  totalPriceElement.textContent = totalPrice.toFixed(2);
}*/
</script>

<style>
button {
  border:0px;
  background-color: transparent;
}
.quantity-input {
    width: 40px;
    text-align: center;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 5px;
}

.btn-quantity {
    background-color: whitesmoke;
    color: rgb(29, 29, 29);
    border: none;
    padding: 5px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.btn-quantity:hover {
    background-color: lightgray;
}

/* Import Google font - Poppins */
#cards {
  margin-top: 80px;
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  grid-gap: 20px;
}

.card {
  color:#333;
  font-size: x-large;
  padding: 10px;
  display: grid;
  box-shadow: 0px 5px 10px rgba(0, 0, 0, .2);
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 10px;
  grid-template-rows: auto 200px auto;
}
.card p {
  color:#333;

}

.card h1 {
  margin-top: 5px;
}

.card img {
  border-radius: 10px;
  width: 100%;
  height: 100%;
}

:global(body) {
  background-color: black;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Helvetica", sans-serif;
}
#current {
  background-color: lightgray;
}
#current:hover {
  background-color: #9fc0ff;
}
.nav_link {
  padding:10px;
  border-radius: 6px;
  font-weight: bold;
  color:#1a1a1a;
  transition: 0.5s;
}
.nav_link:hover {
  color:black;
  background-color: #9fc0ff;
  border-radius: 25px;
}
main {
  background: linear-gradient(217deg, rgba(0, 17, 255, 0.8), rgba(0, 0, 0, 0) 70.71%),
            linear-gradient(127deg, rgba(0, 102, 255, 0.8), rgba(0,255,0,0) 70.71%),
            linear-gradient(336deg, rgba(0, 247, 255, 0.8), rgba(0,0,255,0) 70.71%);
  background-color: #1a1a1a;
}
.container {
  max-width: 1700px;
  width: 100%;
  margin: 0 auto;
}
header {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
}
.nav {
  position:fixed;
  left:1%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 70px;
  width:max-content+1px;
  padding: 0 20px;
  border-radius: 5px;
  background-color: #fff;
  opacity: 75%;
}
.nav_logo {
  margin-top: 20px;
  padding: 10px 0;
}
.menu_items {
  display: flex;
  list-style: none;
  gap: 20px;
}
a {
  color: #1a1a1a;
  text-decoration: none;
}

/* Hero */
.hero {
  position: relative;
  min-height: 100vh;
  width: 100%;
  background-position: 10px 10px, bottom 215px right 10px, left 55% top -1%, left 70% bottom -1px;
  background-repeat: no-repeat;
}
img {
  width:20px;
  height:20px;
}
.hero .row {
  display: flex;
  align-items: center;
  min-height: 100vh;
  height: 100%;
  width: 100%;
  padding: 0 60px;
  gap: 30px;
  justify-content: space-between;
}
.hero .row h2,
.hero .row p {
  color: #fff;
}
.hero .row h2 {
  font-size: 36px;
  margin-bottom: 16px;
}
.hero .column {
  width: 50%;
}
.btn {
  font-size: large;
  padding: 14px 14px;
  background: #fff;
  border-radius: 50px;
  border: none;
  cursor: pointer;
  transition: all 0.3s ease;
}
.btn:last-child {
  border: 2px solid #fff;
  background: transparent;
  color: #fff;
}
.btn:last-child:hover {
  background-color: #fff;
  color: #333;
}
#menu_toggle {
  display: none;
}

/* Reponsive */
@media (width < 1500px) {
  #cards {
    grid-template-columns: repeat(4, 1fr);
  }
}
@media (width < 1200px) {
  .nav {
    left:0;
  }
  #cards {
    grid-template-columns: repeat(3, 1fr);
  }
}
@media (width < 860px) {
  
  #cards {
    grid-template-columns: repeat(2, 1fr);
  }
  #menu_toggle {
    display: block;
  }
  

  .showMenu .menu_items {
    left: 0;
  }
  a {
    color: #333;
  }
  #menu_toggle {
    width: 20px;
    cursor: pointer;
  }
  .menu_items #menu_toggle {
    position: absolute;
    top: 20px;
    right: 20px;
  }
  .hero {
    padding-top: 130px;
  }
  .hero .row {
    flex-direction: column;
    padding: 0 20px;
    justify-content: center;
  }
  .hero .row .column {
    width: 100%;
  }
}

@media (width < 600px) {
  
  #cards {
    grid-template-columns: repeat(1, 1fr);
  }
  .hero {
    padding-top: 80px;
  }
  .hero .row h2 {
    font-size: 26px;
  }
  .nav_logo {
    display: none;
  }
  .btn {
    padding: 10px 10px;
  }
}

* {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}


.container {
  max-width: 1400px;
  padding: 0 15px;
  margin: 0 auto;
}

h2 {
  font-size: 32px;
  margin-bottom: 1em;
}

/* FOOTER STYLES
–––––––––––––––––––––––––––––––––––––––––––––––––– */
.page-footer {
  position: fixed;
  right: 0;
  bottom: 50px;
  display: flex;
  align-items: center;
  padding: 5px;
  z-index: 1;
}

.page-footer a {
  display: flex;
  margin-left: 4px;
}
</style>