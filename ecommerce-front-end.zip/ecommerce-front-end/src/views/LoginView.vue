<script setup>
</script>

<template>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Simple Responsive Website in HTML CSS</title>
  </head>
  <body>
    <main>
      <!-- Header Start -->
      <header>
        <nav class="nav container">
          <h2 class="nav_logo" style="margin-right:10px"><a href="#">PhoneZone</a></h2>

          <ul class="menu_items">
            <li><a href="/" class="nav_link" id="current">Home</a></li>
            <li><a href="/shop" class="nav_link">Shop</a></li>
            <li><a class="nav_link"><img src="https://cdn-icons-png.flaticon.com/512/1413/1413908.png"></img></a></li>
            <li><a href="/login" class="nav_link"><img src="https://cdn-icons-png.flaticon.com/512/266/266033.png"></img></a></li>
          </ul>
        </nav>
      </header>
      <!-- Header End -->

      <!-- Hero Start -->
      <section class="hero">
        <div class="row container">
          <div class="column">
            <h2>Great website to <br />buy phones</h2>
            <p style="font-size: larger;">PhoneZone is an innovative e-commerce platform dedicated to offering the latest smartphones at competitive prices.<br/>The website focuses on delivering a seamless shopping experience with detailed product descriptions, user reviews, and fast, secure checkout.</p>
            <div class="buttons" style="margin-top:20px">
              <button class="btn">Read More</button>
              <a href="/shop" class="btn">Go shopping</a>
            </div>
          </div>
        </div>
      </section>
      <!-- Hero End-->
    </main>
  </body>
</template>

<script>
</script>

<style>
/* Import Google font - Poppins */

:global(body) {
  background-color: black;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Helvetica", sans-serif;
}
#current {
  background-color: lightgray;
}
#current:hover {
  background-color: #9fc0ff;
}
.nav_link {
  padding:10px;
  border-radius: 6px;
  font-weight: bold;
  color:#1a1a1a;
  transition: 0.5s;
}
.nav_link:hover {
  color:black;
  background-color: #9fc0ff;
  border-radius: 25px;
}
main {
  background: linear-gradient(217deg, rgba(0, 17, 255, 0.8), rgba(0, 0, 0, 0) 70.71%),
            linear-gradient(127deg, rgba(0, 102, 255, 0.8), rgba(0,255,0,0) 70.71%),
            linear-gradient(336deg, rgba(0, 247, 255, 0.8), rgba(0,0,255,0) 70.71%);
  background-color: #1a1a1a;
}
.container {
  max-width: 1700px;
  width: 100%;
  margin: 0 auto;
}
header {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
}
.nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 70px;
  width:max-content+1px;
  padding: 0 20px;
  border-radius: 5px;
  background-color: #fff;
  opacity: 75%;
}
.nav_logo {
  margin-top: 20px;
  padding: 10px 0;
}
.menu_items {
  display: flex;
  list-style: none;
  gap: 20px;
}
a {
  color: #1a1a1a;
  text-decoration: none;
}

/* Hero */
.hero {
  position: relative;
  min-height: 100vh;
  width: 100%;
  background-position: 10px 10px, bottom 215px right 10px, left 55% top -1%, left 70% bottom -1px;
  background-repeat: no-repeat;
}
img {
  width:20px;
  height:20px;
}
.hero .row {
  display: flex;
  align-items: center;
  min-height: 100vh;
  height: 100%;
  width: 100%;
  padding: 0 60px;
  gap: 30px;
  justify-content: space-between;
}
.hero .row h2,
.hero .row p {
  color: #fff;
}
.hero .row h2 {
  font-size: 36px;
  margin-bottom: 16px;
}
.hero .column {
  width: 50%;
}
.buttons {
  display: flex;
  margin-top: 5px;
  gap: 10px;
}
.buttons :hover {
  background-color: #fff;
}
.btn {
  padding: 14px 26px;
  background: #fff;
  border-radius: 50px;
  border: none;
  cursor: pointer;
  transition: all 0.3s ease;
}
.btn:last-child {
  border: 2px solid #fff;
  background: transparent;
  color: #fff;
}
.btn:last-child:hover {
  background-color: #fff;
  color: #333;
}
#menu_toggle {
  display: none;
}

/* Reponsive */
@media (width < 860px) {
  #menu_toggle {
    display: block;
  }
  

  .showMenu .menu_items {
    left: 0;
  }
  a {
    color: #333;
  }
  #menu_toggle {
    width: 20px;
    cursor: pointer;
  }
  .menu_items #menu_toggle {
    position: absolute;
    top: 20px;
    right: 20px;
  }
  .hero {
    padding-top: 130px;
  }
  .hero .row {
    flex-direction: column;
    padding: 0 20px;
    justify-content: center;
  }
  .hero .row .column {
    width: 100%;
  }
}

@media (width < 600px) {
  .hero {
    padding-top: 80px;
  }
  .hero .row h2 {
    font-size: 26px;
  }
  .nav_logo {
    display: none;
  }
  .buttons {
    justify-content: center;
  }
  .btn {
    padding: 10px 16px;
  }
}

* {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}


.container {
  max-width: 1400px;
  padding: 0 15px;
  margin: 0 auto;
}

h2 {
  font-size: 32px;
  margin-bottom: 1em;
}
/* FOOTER STYLES
–––––––––––––––––––––––––––––––––––––––––––––––––– */
.page-footer {
  position: fixed;
  right: 0;
  bottom: 50px;
  display: flex;
  align-items: center;
  padding: 5px;
  z-index: 1;
}

.page-footer a {
  display: flex;
  margin-left: 4px;
}
</style>